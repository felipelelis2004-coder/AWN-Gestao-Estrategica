
import React, { useState, useEffect } from 'react';
import { Lead } from '../types';
import { analyzeLeadData } from '../services/geminiService';

const AdminDashboard: React.FC = () => {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [analysis, setAnalysis] = useState<Record<string, any>>({});
  const [isLoading, setIsLoading] = useState<string | null>(null);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem('awn_leads') || '[]');
    setLeads(saved);
  }, []);

  const handleAnalyze = async (lead: Lead) => {
    setIsLoading(lead.id);
    try {
      const result = await analyzeLeadData(lead);
      setAnalysis(prev => ({ ...prev, [lead.id]: result }));
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(null);
    }
  };

  const deleteLead = (id: string) => {
    const updated = leads.filter(l => l.id !== id);
    setLeads(updated);
    localStorage.setItem('awn_leads', JSON.stringify(updated));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold text-[#0f2a44]">Painel de Leads</h2>
        <a href="#" className="text-sm text-blue-600 hover:underline">Voltar para Site</a>
      </div>

      {leads.length === 0 ? (
        <div className="bg-white p-12 rounded-2xl border-2 border-dashed border-gray-200 text-center">
          <i className="fas fa-users-slash text-4xl text-gray-300 mb-4"></i>
          <p className="text-gray-500">Nenhum lead capturado ainda.</p>
        </div>
      ) : (
        <div className="grid gap-6">
          {leads.map(lead => (
            <div key={lead.id} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col md:flex-row gap-6">
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-bold text-slate-800">{lead.nome}</h3>
                    <p className="text-xs text-slate-400 mb-2 uppercase tracking-wide">{lead.data}</p>
                  </div>
                  <span className="bg-blue-50 text-blue-600 px-3 py-1 rounded-full text-xs font-bold">
                    {lead.status}
                  </span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mt-4 text-sm text-slate-600">
                  <div><i className="fas fa-id-card w-6"></i> {lead.cpfcnpj}</div>
                  <div><i className="fas fa-envelope w-6"></i> {lead.email}</div>
                  <div><i className="fas fa-phone w-6"></i> {lead.telefone}</div>
                </div>

                {analysis[lead.id] && (
                  <div className="mt-6 p-4 bg-blue-50 rounded-xl border border-blue-100">
                    <p className="text-xs font-bold text-blue-800 uppercase mb-2">Insight da IA:</p>
                    <div className="flex gap-4 mb-3">
                       <span className="bg-white px-2 py-1 rounded text-[10px] font-bold border border-blue-200">CAT: {analysis[lead.id].category}</span>
                       <span className="bg-white px-2 py-1 rounded text-[10px] font-bold border border-blue-200">PRIO: {analysis[lead.id].priority}</span>
                    </div>
                    <p className="text-sm text-blue-900 italic">"{analysis[lead.id].suggestedHook}"</p>
                  </div>
                )}
              </div>

              <div className="flex md:flex-col gap-2 justify-center">
                <button
                  onClick={() => handleAnalyze(lead)}
                  disabled={!!isLoading}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2 hover:bg-blue-700 transition-colors"
                >
                  {isLoading === lead.id ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-brain"></i>}
                  Analisar
                </button>
                <button
                   onClick={() => window.open(`https://wa.me/${lead.telefone.replace(/\D/g, '')}`, '_blank')}
                   className="bg-green-500 text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2 hover:bg-green-600"
                >
                  <i className="fab fa-whatsapp"></i> WhatsApp
                </button>
                <button
                  onClick={() => deleteLead(lead.id)}
                  className="text-red-400 hover:text-red-600 px-4 py-2 text-xs font-medium"
                >
                  Remover
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
