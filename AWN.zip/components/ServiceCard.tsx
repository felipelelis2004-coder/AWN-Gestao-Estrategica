
import React from 'react';
import { ServiceItem } from '../types';

interface Props {
  item: ServiceItem;
}

const ServiceCard: React.FC<Props> = ({ item }) => {
  return (
    <div className="bg-white p-8 rounded-lg shadow-sm hover:shadow-md transition-all border border-gray-100 group flex flex-col items-center text-center">
      <div className="w-16 h-16 rounded-lg bg-gray-50 flex items-center justify-center mb-6 text-[#0f2a44] transition-colors group-hover:bg-[#0f2a44] group-hover:text-white">
        <i className={`fas ${item.icon} text-2xl`}></i>
      </div>
      <h3 className="text-lg font-bold mb-4 text-slate-800 tracking-tight">{item.title}</h3>
      <p className="text-slate-500 text-sm leading-relaxed mb-6">
        {item.description}
      </p>
      <a 
        href={`https://wa.me/5531990762212?text=Olá,%20gostaria%20de%20consultoria%20sobre%20${item.title}.`}
        target="_blank"
        className="mt-auto text-xs font-bold text-blue-600 uppercase tracking-widest hover:text-blue-800 transition-colors"
      >
        Solicitar consultoria <i className="fas fa-chevron-right ml-1"></i>
      </a>
    </div>
  );
};

export default ServiceCard;
