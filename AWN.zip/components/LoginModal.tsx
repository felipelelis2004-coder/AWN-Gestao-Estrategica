
import React, { useState } from 'react';
import { maskPhone, maskCpfCnpj } from '../utils/formatters';
import { validateCpfCnpj, validateEmail } from '../utils/validators';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

const LoginModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState({ cpf: '', email: '', telefone: '' });
  const [errors, setErrors] = useState({ cpf: false, telefone: false, email: false });

  if (!isOpen) return null;

  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, cpf: maskCpfCnpj(e.target.value) });
    setErrors({ ...errors, cpf: false });
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, telefone: maskPhone(e.target.value) });
    setErrors({ ...errors, telefone: false });
  };

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, email: e.target.value });
    setErrors({ ...errors, email: false });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const isCpfValid = validateCpfCnpj(formData.cpf);
    const isPhoneValid = formData.telefone.replace(/\D/g, "").length >= 10;
    const isEmailValid = validateEmail(formData.email);

    if (!isCpfValid || !isPhoneValid || !isEmailValid) {
      setErrors({
        cpf: !isCpfValid,
        telefone: !isPhoneValid,
        email: !isEmailValid,
      });
      return;
    }

    alert('Acesso restrito. Sua conta está em fase de processamento. Entraremos em contato via WhatsApp para liberar seu painel de acompanhamento.');
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-[#0f2a44]/80 backdrop-blur-md transition-opacity duration-300">
      <div className="bg-white rounded-[2rem] shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="p-8 text-center bg-gradient-to-br from-[#0f2a44] to-[#1a3a5a] text-white">
          <button 
            onClick={onClose}
            className="absolute top-6 right-6 text-white/50 hover:text-white transition-colors"
          >
            <i className="fas fa-times text-xl"></i>
          </button>
          <div className="w-20 h-20 bg-white/10 backdrop-blur-md rounded-3xl flex items-center justify-center mx-auto mb-6 border border-white/20">
            <i className="fas fa-user-check text-3xl"></i>
          </div>
          <h2 className="text-2xl font-bold tracking-tight">Portal do Cliente</h2>
          <p className="text-blue-200 text-sm mt-2 opacity-80">Acesse seus relatórios e acompanhamento estratégico</p>
        </div>
        
        <form onSubmit={handleSubmit} className="p-10 space-y-6">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 ml-1">CPF ou CNPJ</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                <i className="fas fa-id-card"></i>
              </span>
              <input 
                type="text" 
                required
                className={`w-full pl-11 pr-4 py-4 bg-gray-50 border ${errors.cpf ? 'border-red-500' : 'border-gray-100'} rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all placeholder:text-slate-300`}
                placeholder="000.000.000-00"
                value={formData.cpf}
                onChange={handleCpfChange}
              />
            </div>
            {errors.cpf && <p className="text-red-500 text-[10px] mt-1 ml-2 font-bold uppercase">Documento inválido</p>}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 ml-1">E-mail</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                <i className="fas fa-envelope"></i>
              </span>
              <input 
                type="email" 
                required
                className={`w-full pl-11 pr-4 py-4 bg-gray-50 border ${errors.email ? 'border-red-500' : 'border-gray-100'} rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all placeholder:text-slate-300`}
                placeholder="seu@email.com"
                value={formData.email}
                onChange={handleEmailChange}
              />
            </div>
            {errors.email && <p className="text-red-500 text-[10px] mt-1 ml-2 font-bold uppercase">E-mail inválido</p>}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 ml-1">Telefone / WhatsApp</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                <i className="fab fa-whatsapp font-bold"></i>
              </span>
              <input 
                type="tel" 
                required
                className={`w-full pl-11 pr-4 py-4 bg-gray-50 border ${errors.telefone ? 'border-red-500' : 'border-gray-100'} rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all placeholder:text-slate-300`}
                placeholder="(31) 99999-9999"
                value={formData.telefone}
                onChange={handlePhoneChange}
              />
            </div>
            {errors.telefone && <p className="text-red-500 text-[10px] mt-1 ml-2 font-bold uppercase">Telefone inválido</p>}
          </div>

          <button 
            type="submit"
            className="w-full bg-[#0f2a44] text-white font-bold py-5 rounded-2xl hover:bg-blue-900 transition-all shadow-xl shadow-blue-900/10 active:scale-95 flex items-center justify-center gap-3"
          >
            Entrar no Painel <i className="fas fa-arrow-right text-xs"></i>
          </button>
          
          <div className="text-center pt-4 border-t border-gray-50">
            <p className="text-slate-500 text-sm">
              Não tem cadastro ainda?{' '}
              <button 
                type="button"
                onClick={() => {
                  onClose();
                  document.getElementById('contato')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="text-blue-600 font-bold hover:underline"
              >
                Cadastre-se agora
              </button>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginModal;
