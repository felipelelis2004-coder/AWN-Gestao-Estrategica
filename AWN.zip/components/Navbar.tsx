
import React, { useState } from 'react';

interface Props {
  onLoginClick: () => void;
}

const Navbar: React.FC<Props> = ({ onLoginClick }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-white text-slate-800 sticky top-0 z-50 shadow-sm border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <a href="#" className="flex-shrink-0 font-bold text-xl text-[#0f2a44] tracking-tight">
              AWN <span className="text-blue-600 font-light">Gestão Estratégica</span>
            </a>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-8">
              <button 
                onClick={onLoginClick}
                className="text-sm font-medium hover:text-blue-600 transition-colors"
              >
                Login
              </button>
              <a
                href="https://wa.me/5531990762212?text=Olá,%20gostaria%20de%20mais%20informações%20sobre%20os%20serviços%20da%20AWN%20Gestão%20Estratégica."
                target="_blank"
                className="bg-[#0f2a44] px-6 py-2.5 rounded text-white text-sm font-bold hover:bg-blue-900 transition-all shadow-md"
              >
                Contato
              </a>
            </div>
          </div>
          <div className="flex md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-slate-800"
            >
              <i className={`fas ${isOpen ? 'fa-times' : 'fa-bars'} text-xl`}></i>
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-white px-4 pt-2 pb-6 space-y-3 animate-in fade-in slide-in-from-top-2 border-t border-gray-100">
          <button onClick={() => { setIsOpen(false); onLoginClick(); }} className="block w-full text-left px-3 py-2 text-base font-medium">Login</button>
          <a
            href="https://wa.me/5531990762212"
            className="block px-3 py-3 rounded bg-[#0f2a44] text-white text-center font-bold"
          >
            Contato
          </a>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
