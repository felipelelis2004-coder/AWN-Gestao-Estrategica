
import React from 'react';
import { SLOGAN } from '../constants';

const Hero: React.FC = () => {
  return (
    <div className="relative bg-white pt-20 pb-28 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 flex flex-col lg:flex-row items-center gap-16">
        <div className="flex-1 text-center lg:text-left z-10 animate-in fade-in slide-in-from-left duration-700">
          <span className="inline-block bg-blue-50 text-blue-700 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest mb-6 border border-blue-100">
            {SLOGAN}
          </span>
          <h1 className="text-5xl lg:text-7xl font-extrabold text-[#0f2a44] leading-[1.05] mb-8 tracking-tighter">
            Organização que gera <span className="text-blue-600">liberdade</span> para você prosperar.
          </h1>
          <p className="text-xl text-slate-600 mb-10 leading-relaxed max-w-xl font-medium">
            Apoiamos MEIs e pequenos negócios com processos claros e controle financeiro. Tenha segurança para decidir os próximos passos do seu negócio.
          </p>
          <div className="flex flex-wrap justify-center lg:justify-start gap-5">
            <a 
              href="https://wa.me/5531990762212?text=Olá,%20gostaria%20de%20saber%20mais%20sobre%20a%20AWN."
              target="_blank"
              className="rounded-xl bg-[#0f2a44] px-12 py-5 text-base font-bold text-white shadow-2xl hover:bg-blue-900 transition-all transform hover:-translate-y-1 active:scale-95 flex items-center gap-3"
            >
              Falar com especialista agora <i className="fab fa-whatsapp text-lg text-green-400"></i>
            </a>
          </div>
        </div>
        
        <div className="flex-1 relative animate-in fade-in slide-in-from-right duration-1000">
          <div className="relative rounded-[2.5rem] overflow-hidden shadow-[0_35px_60px_-15px_rgba(0,0,0,0.3)] border-8 border-white">
            <img 
              src="https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=1200" 
              alt="Empresário contente analisando dados de gestão e resultados" 
              className="w-full h-auto object-cover transform hover:scale-105 transition-transform duration-700"
            />
          </div>
          
          <div className="absolute -bottom-8 -left-8 bg-white p-6 rounded-3xl shadow-2xl border border-gray-50 hidden sm:block">
             <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-blue-200">
                  <i className="fas fa-chart-line text-xl"></i>
                </div>
                <div>
                   <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-0.5">Visão Estratégica</p>
                   <p className="text-sm font-bold text-[#0f2a44]">Dados para sua decisão</p>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
