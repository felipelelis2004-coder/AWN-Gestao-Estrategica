
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ServiceCard from './components/ServiceCard';
import ChatWidget from './components/ChatWidget';
import LoginModal from './components/LoginModal';
import AdminDashboard from './components/AdminDashboard';
import { Lead } from './types';
import { SERVICES, EXCLUSIONS, ABOUT_TEXT, SLOGAN } from './constants';
import { maskPhone, maskCpfCnpj } from './utils/formatters';
import { validateCpfCnpj, validateEmail } from './utils/validators';

const App: React.FC = () => {
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [formState, setFormState] = useState({
    nome: '',
    cpfcnpj: '',
    telefone: '',
    email: '',
  });
  const [errors, setErrors] = useState({
    cpfcnpj: false,
    telefone: false,
    email: false,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const handleHashChange = () => {
      setIsAdmin(window.location.hash === '#/admin');
    };
    window.addEventListener('hashchange', handleHashChange);
    handleHashChange();
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const masked = maskPhone(e.target.value);
    setFormState({ ...formState, telefone: masked });
    setErrors({ ...errors, telefone: false });
  };

  const handleCpfCnpjChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const masked = maskCpfCnpj(e.target.value);
    setFormState({ ...formState, cpfcnpj: masked });
    setErrors({ ...errors, cpfcnpj: false });
  };

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormState({ ...formState, email: e.target.value });
    setErrors({ ...errors, email: false });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const isCpfCnpjValid = validateCpfCnpj(formState.cpfcnpj);
    const isPhoneValid = formState.telefone.replace(/\D/g, "").length >= 10;
    const isEmailValid = validateEmail(formState.email);

    if (!isCpfCnpjValid || !isPhoneValid || !isEmailValid) {
      setErrors({
        cpfcnpj: !isCpfCnpjValid,
        telefone: !isPhoneValid,
        email: !isEmailValid,
      });
      return;
    }

    setIsSubmitting(true);

    const newLead: Lead = {
      ...formState,
      id: crypto.randomUUID(),
      data: new Date().toLocaleString('pt-BR'),
      status: 'Pendente'
    };

    const leads = JSON.parse(localStorage.getItem('awn_leads') || '[]');
    leads.push(newLead);
    localStorage.setItem('awn_leads', JSON.stringify(leads));

    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      setFormState({ nome: '', cpfcnpj: '', telefone: '', email: '' });
      setTimeout(() => setSubmitted(false), 5000);
    }, 800);
  };

  if (isAdmin) {
    return <AdminDashboard />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-white selection:bg-blue-100 selection:text-blue-900">
      <Navbar onLoginClick={() => setIsLoginOpen(true)} />
      <LoginModal isOpen={isLoginOpen} onClose={() => setIsLoginOpen(false)} />
      
      <main className="flex-grow">
        <Hero />

        {/* Sobre a AWN - Conheça nossa essência */}
        <section id="sobre" className="py-24 bg-white border-t border-gray-50 scroll-mt-24">
          <div className="max-w-6xl mx-auto px-6 text-center">
            <span className="inline-block text-blue-600 font-black text-[10px] uppercase tracking-[0.3em] mb-4">Conheça nossa essência</span>
            <h2 className="text-3xl lg:text-4xl font-bold text-[#0f2a44] mb-8 tracking-tight">Sobre a AWN</h2>
            <div className="text-xl text-slate-600 leading-relaxed font-normal max-w-4xl mx-auto whitespace-pre-wrap">
              <p>{ABOUT_TEXT}</p>
            </div>
          </div>
        </section>

        {/* Nossos Serviços */}
        <section id="servicos" className="py-24 bg-gray-50/50 scroll-mt-24">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-[#0f2a44] tracking-tight">Nossos Serviços</h2>
              <p className="mt-4 text-xl text-slate-500 max-w-2xl mx-auto">Tudo o que sua empresa precisa para ter uma gestão organizada e profissional.</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
              {SERVICES.map((service, idx) => (
                <ServiceCard key={idx} item={service} />
              ))}
            </div>

            <div className="flex justify-center">
              <a 
                href="https://wa.me/5531990762212?text=Olá!%20Gostaria%20de%20conhecer%20mais%20serviços%20da%20AWN%20Gestão%20Estratégica%20além%20dos%20citados%20no%20site."
                target="_blank"
                className="bg-white border-2 border-[#0f2a44] text-[#0f2a44] px-10 py-4 rounded-xl font-bold hover:bg-[#0f2a44] hover:text-white transition-all transform hover:-translate-y-1 shadow-lg flex items-center gap-3"
              >
                Confira mais serviços <i className="fas fa-plus-circle"></i>
              </a>
            </div>
          </div>
        </section>

        {/* Seção Custo-Benefício */}
        <section className="py-24 bg-[#0f2a44] overflow-hidden relative">
          <div className="absolute top-0 right-0 w-1/3 h-full bg-blue-600/10 -skew-x-12 transform translate-x-1/2"></div>
          <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <div>
                <span className="text-blue-400 font-black text-[10px] uppercase tracking-[0.3em] mb-4 block">Eficiência Máxima</span>
                <h2 className="text-4xl lg:text-5xl font-bold text-white mb-8 tracking-tight">Gestão Profissional que cabe no seu bolso.</h2>
                <div className="space-y-6">
                   <div className="flex gap-4 items-start">
                      <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center shrink-0 border border-white/10">
                        <i className="fas fa-wallet text-blue-400"></i>
                      </div>
                      <div>
                         <h4 className="text-xl font-bold text-white mb-2">Invista pouco, ganhe clareza</h4>
                         <p className="text-blue-100/70">Reduzimos a complexidade para que você foque no que realmente importa: crescer o seu negócio.</p>
                      </div>
                   </div>
                   <div className="flex gap-4 items-start">
                      <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center shrink-0 border border-white/10">
                        <i className="fas fa-bolt text-blue-400"></i>
                      </div>
                      <div>
                         <h4 className="text-xl font-bold text-white mb-2">Retorno rápido para seu negócio</h4>
                         <p className="text-blue-100/70">Organização imediata que se traduz em decisões mais rápidas e lucrativas desde o primeiro mês.</p>
                      </div>
                   </div>
                </div>
              </div>
              <div className="bg-white/5 backdrop-blur-sm p-10 rounded-[3rem] border border-white/10 shadow-2xl">
                 <div className="text-center mb-10">
                    <p className="text-blue-400 font-bold mb-2">Sua empresa merece ser grande.</p>
                    <p className="text-white text-3xl font-bold">Por que escolher a AWN?</p>
                 </div>
                 <div className="grid grid-cols-2 gap-6">
                    <div className="bg-white/5 p-6 rounded-2xl border border-white/5 text-center">
                       <i className="fas fa-shield-heart text-2xl text-blue-400 mb-3"></i>
                       <p className="text-white font-bold text-sm">Segurança Total</p>
                    </div>
                    <div className="bg-white/5 p-6 rounded-2xl border border-white/5 text-center">
                       <i className="fas fa-chart-line text-2xl text-blue-400 mb-3"></i>
                       <p className="text-white font-bold text-sm">Alta Performance</p>
                    </div>
                    <div className="bg-white/5 p-6 rounded-2xl border border-white/5 text-center">
                       <i className="fas fa-user-check text-2xl text-blue-400 mb-3"></i>
                       <p className="text-white font-bold text-sm">Foco no MEI</p>
                    </div>
                    <div className="bg-white/5 p-6 rounded-2xl border border-white/5 text-center">
                       <i className="fas fa-sync text-2xl text-blue-400 mb-3"></i>
                       <p className="text-white font-bold text-sm">Processos Ágeis</p>
                    </div>
                 </div>
              </div>
            </div>
          </div>
        </section>

        {/* Transparência e Escopo (O que NÃO fazemos) */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="bg-gray-50 p-12 lg:p-16 rounded-[3rem] border border-gray-100 flex flex-col md:flex-row gap-12 items-center">
               <div className="w-20 h-20 bg-white text-[#0f2a44] rounded-2xl flex items-center justify-center shrink-0 shadow-lg">
                 <i className="fas fa-shield-alt text-3xl"></i>
               </div>
               <div>
                  <h3 className="text-blue-600 font-black text-[10px] uppercase tracking-[0.3em] mb-4">Transparência e Escopo</h3>
                  <h4 className="text-3xl font-bold text-[#0f2a44] mb-6">Onde começa e termina nossa atuação.</h4>
                  <p className="text-lg text-slate-500 mb-10 leading-relaxed">Focamos em organização administrativa. Por transparência, listamos os serviços que <span className="text-[#0f2a44] font-bold underline decoration-blue-500 underline-offset-4">não realizamos</span>, garantindo o foco na sua estratégia:</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    {EXCLUSIONS.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-3 p-4 bg-white rounded-xl border border-gray-100 group hover:shadow-md transition-all">
                         <i className="fas fa-times-circle text-red-400"></i>
                         <span className="text-sm font-bold text-slate-600">{item.title}</span>
                      </div>
                    ))}
                  </div>
               </div>
            </div>
          </div>
        </section>

        {/* Lead Form Section */}
        <section id="contato" className="py-32 bg-gray-50/30 scroll-mt-24">
          <div className="max-w-6xl mx-auto px-6 lg:px-8 flex flex-col lg:flex-row gap-20 items-center">
            <div className="flex-1 lg:max-w-md">
               <span className="text-blue-600 font-black text-[10px] uppercase tracking-[0.3em] mb-4 block">Comece agora</span>
               <h2 className="text-4xl lg:text-5xl font-bold text-[#0f2a44] mb-8 tracking-tight">Pronto para organizar sua empresa?</h2>
               <p className="text-xl text-slate-500 mb-10 leading-relaxed">Preencha seus dados para receber um diagnóstico inicial da sua gestão estratégica.</p>
               <div className="flex items-center gap-4 p-5 bg-white rounded-2xl border border-gray-100 text-sm font-bold text-blue-700 shadow-sm">
                  <i className="fas fa-user-shield text-xl"></i> 
                  <span>Dados protegidos por nossa política de privacidade.</span>
               </div>
            </div>

            <div className="flex-1 w-full bg-white p-8 lg:p-14 rounded-[3rem] shadow-[0_50px_100px_-20px_rgba(0,0,0,0.1)] border border-gray-100">
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <input
                    type="text"
                    required
                    value={formState.nome}
                    onChange={e => setFormState({...formState, nome: e.target.value})}
                    className="w-full px-5 py-4 rounded-xl bg-gray-50 border border-gray-100 focus:bg-white focus:border-blue-200 outline-none transition-all placeholder:text-slate-400"
                    placeholder="Seu nome"
                  />
                  <div>
                    <input
                      type="text"
                      required
                      value={formState.cpfcnpj}
                      onChange={handleCpfCnpjChange}
                      className={`w-full px-5 py-4 rounded-xl bg-gray-50 border ${errors.cpfcnpj ? 'border-red-500' : 'border-gray-100'} focus:bg-white focus:border-blue-200 outline-none transition-all placeholder:text-slate-400`}
                      placeholder="CPF ou CNPJ"
                    />
                    {errors.cpfcnpj && <p className="text-red-500 text-[10px] mt-1 ml-2 font-bold uppercase">Documento inválido</p>}
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <input
                      type="tel"
                      required
                      value={formState.telefone}
                      onChange={handlePhoneChange}
                      className={`w-full px-5 py-4 rounded-xl bg-gray-50 border ${errors.telefone ? 'border-red-500' : 'border-gray-100'} focus:bg-white focus:border-blue-200 outline-none transition-all placeholder:text-slate-400`}
                      placeholder="WhatsApp"
                    />
                    {errors.telefone && <p className="text-red-500 text-[10px] mt-1 ml-2 font-bold uppercase">Telefone inválido</p>}
                  </div>
                  <div>
                    <input
                      type="email"
                      required
                      value={formState.email}
                      onChange={handleEmailChange}
                      className={`w-full px-5 py-4 rounded-xl bg-gray-50 border ${errors.email ? 'border-red-500' : 'border-gray-100'} focus:bg-white focus:border-blue-200 outline-none transition-all placeholder:text-slate-400`}
                      placeholder="E-mail"
                    />
                    {errors.email && <p className="text-red-500 text-[10px] mt-1 ml-2 font-bold uppercase">E-mail inválido</p>}
                  </div>
                </div>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-[#0f2a44] text-white font-bold py-5 rounded-2xl hover:bg-blue-900 transition-all flex items-center justify-center gap-3 shadow-xl shadow-blue-900/10"
                >
                  {isSubmitting ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-paper-plane"></i>}
                  Enviar dados para análise
                </button>
                {submitted && (
                  <div className="p-4 bg-green-50 text-green-700 rounded-xl text-center font-bold text-sm">
                    <i className="fas fa-check-circle mr-2"></i> Recebemos seus dados!
                  </div>
                )}
              </form>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-[#0f2a44] text-white py-24">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-16 text-center md:text-left">
          <div>
            <h2 className="text-3xl font-bold mb-6">AWN <span className="text-blue-400 font-light">Gestão Estratégica</span></h2>
            <p className="text-blue-200 text-lg italic mb-6 opacity-80">"{SLOGAN}"</p>
          </div>
          <div>
            <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-blue-400 mb-8">Navegação</h4>
            <ul className="text-sm space-y-4 font-medium">
              <li>
                <button 
                  onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} 
                  className="hover:text-blue-300 transition-colors w-full text-left md:w-auto"
                >
                  Início
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('sobre')} 
                  className="hover:text-blue-300 transition-colors w-full text-left md:w-auto"
                >
                  Sobre a Empresa
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('servicos')} 
                  className="hover:text-blue-300 transition-colors w-full text-left md:w-auto"
                >
                  Serviços
                </button>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-blue-400 mb-8">Contato</h4>
            <a
              href="https://wa.me/5531990762212"
              target="_blank"
              className="bg-white text-[#0f2a44] px-8 py-4 rounded-2xl font-bold inline-flex items-center gap-3 hover:bg-blue-100 transition-all shadow-lg"
            >
              <i className="fab fa-whatsapp text-xl text-green-500"></i>
              WhatsApp Direto
            </a>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-6 mt-20 pt-10 border-t border-white/5 text-center text-[10px] text-blue-500 uppercase font-black tracking-[0.4em]">
          &copy; {new Date().getFullYear()} AWN Gestão Estratégica. {SLOGAN}.
        </div>
      </footer>

      <ChatWidget />
    </div>
  );
};

export default App;
