
import { ServiceItem } from './types';

export const COLORS = {
  primary: '#0f2a44',
  secondary: '#123a60',
  accent: '#25D366',
  background: '#ffffff',
};

export const SLOGAN = "organização para sua decisão";

export const ABOUT_TEXT = `A AWN Gestão Estratégica atua no apoio administrativo e organizacional de pequenos negócios e MEIs, oferecendo estrutura, controle e clareza para a gestão do dia a dia.

Nosso trabalho é transformar informações dispersas em dados organizados, facilitando o acompanhamento financeiro, a análise de resultados e a tomada de decisões mais seguras. Atuamos com foco em simplicidade, organização e continuidade, respeitando a realidade de cada negócio.`;

export const SERVICES: ServiceItem[] = [
  {
    title: 'Organização Administrativa',
    description: 'Soluções modulares desenhadas para as necessidades específicas do MEI e do pequeno empreendedor.',
    icon: 'fa-layer-group',
    type: 'service'
  },
  {
    title: 'Controle Financeiro',
    description: 'Gestão de fluxo de caixa, conciliação bancária e organização de contas com foco em clareza.',
    icon: 'fa-chart-pie',
    type: 'service'
  },
  {
    title: 'Relatórios Gerenciais',
    description: 'Transformamos seus números em relatórios visuais simples para apoiar sua tomada de decisão.',
    icon: 'fa-file-alt',
    type: 'service'
  },
  {
    title: 'Apoio à Gestão',
    description: 'Suporte direto na organização financeira para garantir que sua operação esteja sempre segura.',
    icon: 'fa-user-tie',
    type: 'service'
  }
];

export const EXCLUSIONS: ServiceItem[] = [
  {
    title: 'Contabilidade formal',
    description: 'Não realizamos balanços contábeis ou obrigações acessórias do contador.',
    icon: 'fa-check',
    type: 'exclusion'
  },
  {
    title: 'Serviços jurídicos',
    description: 'Questões legais devem ser tratadas com advogados especializados.',
    icon: 'fa-check',
    type: 'exclusion'
  },
  {
    title: 'Consultoria tributária',
    description: 'Planejamento de impostos não faz parte do nosso escopo administrativo.',
    icon: 'fa-check',
    type: 'exclusion'
  },
  {
    title: 'Emissão de notas fiscais',
    description: 'O processo operacional de emissão fica a cargo do cliente ou contador.',
    icon: 'fa-check',
    type: 'exclusion'
  }
];
