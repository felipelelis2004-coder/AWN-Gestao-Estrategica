import { GoogleGenAI, Type } from "@google/genai";

// Fixed: Initializing GoogleGenAI using process.env.API_KEY directly as a named parameter.
export const getGeminiResponse = async (prompt: string, history: { role: 'user' | 'model', parts: { text: string }[] }[] = []) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [
      ...history,
      { role: 'user', parts: [{ text: prompt }] }
    ],
    config: {
      systemInstruction: `Você é o Assistente Virtual da AWN Gestão Estratégica. 
      Sua missão é ajudar pequenos empresários e MEIs a entenderem a importância da organização administrativa e financeira.
      
      Serviços da AWN:
      - Organização administrativa e de processos.
      - Controle financeiro (entradas e saídas).
      - Elaboração de relatórios mensais claros.
      - Apoio à gestão de pequenos negócios.
      
      O que a AWN NÃO faz:
      - Contabilidade formal (balanços, obrigações legais).
      - Serviços jurídicos.
      - Emissão de notas fiscais.
      - Consultoria tributária.

      Seja profissional, prestativo e utilize um tom de voz que gere confiança e clareza. 
      Responda sempre em Português do Brasil. 
      Se o usuário perguntar sobre preços, diga que cada projeto é personalizado e peça para ele preencher o formulário de contato ou chamar no WhatsApp (31 99076-2212).`,
    }
  });

  return response.text;
};

export const analyzeLeadData = async (leadData: any) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analise este novo lead para a AWN Gestão Estratégica e forneça uma breve estratégia de abordagem: ${JSON.stringify(leadData)}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          category: { type: Type.STRING, description: "Categoria do cliente (ex: MEI, Pequeno Negócio, Potencial Alto)" },
          priority: { type: Type.STRING, description: "Prioridade (Baixa, Média, Alta)" },
          suggestedHook: { type: Type.STRING, description: "Frase de abertura sugerida para o WhatsApp" }
        },
        required: ["category", "priority", "suggestedHook"]
      }
    }
  });

  return JSON.parse(response.text || '{}');
};
