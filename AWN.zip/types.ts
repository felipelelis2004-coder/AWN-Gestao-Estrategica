
export interface Lead {
  id: string;
  nome: string;
  cpfcnpj: string;
  telefone: string;
  email: string;
  data: string;
  status: 'Pendente' | 'Contatado' | 'Arquivado';
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface ServiceItem {
  title: string;
  description: string;
  icon: string;
  type: 'service' | 'exclusion';
}
